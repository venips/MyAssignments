package com.prj;
import java.util.Set;

public interface PassportDAO 
{	void addPassport(Passport passport);
	void modifyPassport(Passport passport);
	void deletePassport(int passportno);
	Passport findPassport(int passportno);
	Set<Passport> findAllPassport();

}
