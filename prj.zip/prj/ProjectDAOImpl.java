package com.prj;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.Test;

public class ProjectDAOImpl implements ProjectDAO

{

	EntityManagerFactory emf;
	EntityManager em;

	public ProjectDAOImpl() {

		// TODO Auto-generated constructor stub
		System.out.println("before EntityManagerFactory created....");
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory created....");

		this.em = emf.createEntityManager();
		System.out.println("EntityManager created....");
	}

	@Test
	public void SampleProjectTest() {
		Project project1 = new Project();
		Project project2 = new Project();
		Project project3 = new Project();

		project1.setProjectTitle("Mobile Banking");
		project1.setProjectDeadLine(LocalDate.of(2022, 04, 04));

		project2.setProjectTitle("Travel Project");
		project2.setProjectDeadLine(LocalDate.of(2022, 05, 04));

		project3.setProjectTitle("Retail Banking");
		project3.setProjectDeadLine(LocalDate.of(2023, 05, 04));

		Project p2 = findProject(8);
		if (p2 != null) {
			System.out.println(p2.getProjectId());
			System.out.println(p2.getProjectTitle());
			System.out.println(p2.getProjectDeadLine());
		} else
			System.out.println("No Mathcing");

		Set<Project> st = findAllProject();
		for (Project p : st) {
			System.out.println("Project Id" + p.getProjectId());
			System.out.println("Project Title" + p.getProjectTitle());
			System.out.println("Project Completion" + p.getProjectDeadLine());

			System.out.println("------------------------------------------------------------------");

		}

	}

	public void addProject(Project p) {
		// TODO Auto-generated method stub

		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(p);
		System.out.println("persist");
		et.commit();

	}

	public void modifyProject(Project p) {
		// TODO Auto-generated method stub

		EntityTransaction et = em.getTransaction();
		et.begin();
		em.merge(p);
		et.commit();

	}

	public void deleteProject(int pno) {
		// TODO Auto-generated method stub
		EntityTransaction et = em.getTransaction();
		et.begin();
		Project p = em.find(Project.class, pno);
		em.remove(p);
		et.commit();

	}

	public Project findProject(int pno) {
		// TODO Auto-generated method stub
		return em.find(Project.class, pno);
	}

	public Set<Project> findAllProject() {
		// TODO Auto-generated method stub
		Query query = em.createQuery("from Project");
		List<Project> list = query.getResultList();
		Set<Project> empSet = new HashSet(list);
		return empSet;
	}

}
