package com.prj;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Passport {
		@Id
		@GeneratedValue
		private int passportId; // <-- primary key
		private LocalDate passportIssuedDate;
		private LocalDate passportExpiryDate;
		private String issuedBy;
		
		public int getPassportId() {
			return passportId;
		}
		public void setPassportId(int passportId) {
			this.passportId = passportId;
		}
		public LocalDate getPassportIssuedDate() {
			return passportIssuedDate;
		}
		public void setPassportIssuedDate(LocalDate passportIssuedDate) {
			this.passportIssuedDate = passportIssuedDate;
		}
		public LocalDate getPassportExpiryDate() {
			return passportExpiryDate;
		}
		public void setPassportExpiryDate(LocalDate passportExpiryDate) {
			this.passportExpiryDate = passportExpiryDate;
		}
		public String getIssuedBy() {
			return issuedBy;
		}
		public void setIssuedBy(String issuedBy) {
			this.issuedBy = issuedBy;
		}
		@Override
		public String toString() {
			return "Passport [passportId=" + passportId + ", passportIssuedDate=" + passportIssuedDate
					+ ", passportExpiryDate=" + passportExpiryDate + ", issuedBy=" + issuedBy + "]";
		}
		
		
	

}
