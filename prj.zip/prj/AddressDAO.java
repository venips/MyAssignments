package com.prj;

import java.util.Set;

public interface AddressDAO 
{
	void addAddress(Address address);

	void modifyAddress(Address address);

	void deleteAddress(int addressno);

	Address findAddress(int addressno);

	Set<Address> findAllAddress();

}
