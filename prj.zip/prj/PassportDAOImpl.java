package com.prj;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.Test;

public class PassportDAOImpl implements PassportDAO {
	EntityManagerFactory emf;
	EntityManager em;

	public PassportDAOImpl() {

		// TODO Auto-generated constructor stub
		System.out.println("before EntityManagerFactory created....");
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory created....");

		this.em = emf.createEntityManager();
		System.out.println("EntityManager created....");
	}

	@Test
	public void SamplePassportTest() {

		Passport p1 = new Passport();
		Passport pl = new Passport();
		System.out.println("Setting passport");
		// p1.setPassportId(1);
		p1.setIssuedBy("Govt of India");
		p1.setPassportIssuedDate(LocalDate.of(2021, 4, 4));
		p1.setPassportExpiryDate(LocalDate.of(2031, 4, 4));

		pl.setIssuedBy("Govt of UK");
		pl.setPassportIssuedDate(LocalDate.of(2010, 3, 4));
		pl.setPassportExpiryDate(LocalDate.of(2020, 3, 4));

		addPassport(p1);
		addPassport(pl);


		Set<Passport> st = findAllPassport();
		for (Passport p : st) {
			System.out.println("Passport Number" + p.getPassportId());
			System.out.println("Passport Issued Place" + p.getIssuedBy());
			System.out.println("Passport Issue Date" + p.getPassportIssuedDate());
			System.out.println("Passport Expiry Date" + p.getPassportExpiryDate());

			System.out.println("------------------------------------------------------------------");

		}

	}

	public void addPassport(Passport passport) {
		// TODO Auto-generated method stub

		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(passport);
		System.out.println("persist");
		et.commit();

	}

	public void modifyPassport(Passport passport) {
		// TODO Auto-generated method stub
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.merge(passport);
		et.commit();

	}

	public void deletePassport(int passportno) {
		// TODO Auto-generated method stub
		EntityTransaction et = em.getTransaction();
		et.begin();
		Passport p = em.find(Passport.class, passportno);
		em.remove(p);
		et.commit();

	}

	public Passport findPassport(int passportno) {
		// TODO Auto-generated method stub
		return em.find(Passport.class, passportno);
	}

	public Set<Passport> findAllPassport() {
		// TODO Auto-generated method stub

		Query query = em.createQuery("from Passport");
		List<Passport> list = query.getResultList();
		Set<Passport> empSet = new HashSet(list);
		return empSet;

	}

}
