package com.prj;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class AddressDAOImpl implements AddressDAO {
	EntityManagerFactory emf;
	EntityManager em;
  
	public AddressDAOImpl() {
		// TODO Auto-generated constructor stub
		System.out.println("before EntityManagerFactory created....");
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory created....");

		this.em = emf.createEntityManager();
		System.out.println("EntityManager created....");
		// TODO Auto-generated constructor stub
	}

	public void addAddress(Address address) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub

		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(address);
		System.out.println("persist");
		et.commit();
	}

	public void modifyAddress(Address address) {
		// TODO Auto-generated method stub

		EntityTransaction et = em.getTransaction();
		et.begin();
		em.merge(address);
		et.commit();

	}

	public void deleteAddress(int addressno) {
		// TODO Auto-generated method stub

		EntityTransaction et = em.getTransaction();
		et.begin();
		Address p = em.find(Address.class, addressno);
		em.remove(p);
		et.commit();

	}

	public Address findAddress(int pno) {
		// TODO Auto-generated method stub
		return em.find(Address.class, pno);
	}

	public Set<Address> findAllAddress() {
		// TODO Auto-generated method stub
		Query query = em.createQuery("from Address");
		List<Address> list = query.getResultList();
		Set<Address> empSet = new HashSet(list);
		return empSet;
	}

}
