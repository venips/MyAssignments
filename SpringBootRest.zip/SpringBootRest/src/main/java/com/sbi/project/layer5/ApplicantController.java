package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;

@RestController
@RequestMapping("/applicants")

public class ApplicantController {

@Autowired
ApplicantService applicantService;

	public ApplicantController() {
		System.out.println("Applicant Controller() constructor...");
			
		}
	
	@RequestMapping("/getApplicants")
	public List<Applicant> getAllApplicants(){
		System.out.println("/getApplicants");
		return applicantService.getAllApplicants();
	}
	@RequestMapping("/createApplicant")
	public void createApplication() {
		
		System.out.println("Application controller create application module");
		Applicant app1=new Applicant();
		
		app1.setAccountType("CURRENT");
	
		app1.setAadharNumber("123489098789");
		app1.setAnnualIncome("30000");
		app1.setApplicantBirthDate(LocalDate.of(1998, 11, 18));
		app1.setApplicantFatherName("Amit");
		app1.setApplicantName("Karthik");
		app1.setApplicationStatus("Pending");
		app1.setMarried("No");
		app1.setMobileNumber("8095063190");
		app1.setOccupation("IT");
		app1.setPanCard("CRJPX8909");
		app1.setPhoto("pic.jpg");
		
	
		
		applicantService.createApplicationService(app1);
		System.out.println("ApplicantServiceImpl() : created the applicants data.....");

	}
	@RequestMapping("/findApplicant/{appid}")
	public Applicant findApplication(@PathVariable("appid") int applicantId) 
	{
		return applicantService.findApplication(applicantId);
	
	}
	
	@RequestMapping("/updateApplicant")
	public void modifyApplication(@RequestBody Applicant account) 
	{
		applicantService.modifyApplication(account);
	}
	
	@RequestMapping("/deleteApplicant/{appid}")
	public void removeApplication(@PathVariable("appid") int applicantId)
	{	applicantService.removeApplication(applicantId);
		
	}
	/*
	@RequestMapping("/getEmp/{eno}")
	public Employee getEmployee(@PathVariable("eno") int employeeNumberToSearch) {
		System.out.println("/getEmp");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeNumberToSearch) {
				employeeFound=true;
				break;
			}
		}
		if(employeeFound==true)
		return employeeObject;
		else
			throw new RuntimeException("Employee not Found");
	}

	@RequestMapping("/deleteEmp/{eno}")
	public String deleteEmployee(@PathVariable("eno") int employeeNumberToDelete) {
		System.out.println("/deleteEmp");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeNumberToDelete) {
				employeeFound=true;
				staff.remove(i);
				break;
			}
		}
		if(employeeFound==true)
		return "Employee Object deleted" +employeeNumberToDelete;
		else
			return "Employee Object not Found :" +employeeNumberToDelete;
	}
	
	@RequestMapping("/updateEmp")
	public String updateEmployee(@RequestBody Employee employeeObjectToModify) {
		System.out.println("/updateEmp");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeObjectToModify.getEmployeeNumber()) {
				employeeFound=true;
				staff.remove(i);
				staff.add(employeeObjectToModify);
				break;
			}
		}
		if(employeeFound==true)
		return "Employee Object Successfully modified";
		else
			return "Employee Object not found: "+employeeObjectToModify.getEmployeeNumber();
	}
	@RequestMapping("/addEmp")
	public String addEmployee(@RequestBody Employee employeeObjectToAdd) {
		System.out.println("/addEmp");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeObjectToAdd.getEmployeeNumber()) {
				employeeFound=true;
				break;
			}
		}
		if(employeeFound==true)
		return "Employee already exists :" +employeeObjectToAdd.getEmployeeNumber();
		else
			staff.add(employeeObjectToAdd);
			return "Employee Object added successfully";
	}*/
}
