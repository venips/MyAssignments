package com.sbi.project.layer2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component @Entity @Table(name="applicant_tbl")
public class Applicant {
	
	
	
	@Id
	@GeneratedValue
	@Column(name="applicant_id")
	private int applicantId;
	
	@Column(name="account_type")
	private String accountType;
	
	@Column(name="applicant_name")
	private String applicantName;
	
	@Column(name="applicant_fname")
	private String applicantFatherName;

	@Column(name="applicant_dob")
	private LocalDate applicantBirthDate;
	
	@Column(name="applicant_mobile")
	private String mobileNumber;
	
	@Column(name="applicant_married")
	private String married;
	
	@Column(name="applicant_occupation")
	private String occupation;
	
	@OneToMany(mappedBy ="applicant" ,cascade = CascadeType.ALL)
	List<Address> addressList = new ArrayList<Address>();
	
	@Column(name="applicant_aadhar")
	private String aadharNumber;
	
	@Column(name="applicant_pancard")
	private String panCard;
	
	@Column(name="applicant_photo")
	private String photo;
	
	@Column(name="applicant_annualincome")
	private String annualIncome;
	
	@Column(name="application_status")
	private String applicationStatus;

	public int getApplicantId() {
		return applicantId;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getMarried() {
		return married;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getApplicantFatherName() {
		return applicantFatherName;
	}

	public void setApplicantFatherName(String applicantFatherName) {
		this.applicantFatherName = applicantFatherName;
	}

	public LocalDate getApplicantBirthDate() {
		return applicantBirthDate;
	}

	public void setApplicantBirthDate(LocalDate applicantBirthDate) {
		this.applicantBirthDate = applicantBirthDate;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String isMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
}
