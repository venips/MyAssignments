package com.sbi.project.layer5;

import java.time.LocalDate;

public class Employee {
	
	
	private int employeeNumber;
	
	private String name;
	
	private String job;
	
	private LocalDate joiningdate;
	
	private double salary;
	
	private String age;
	
	
	public Employee(int employeeNumber,String name, String job, LocalDate joiningdate, double salary, String age) {
		super();
		this.employeeNumber = employeeNumber;
		this.name = name;
		this.job = job;
		this.joiningdate = joiningdate;
		this.salary = salary;
		this.age = age;
		
	}

	

	public Employee() {
		super();
		System.out.println("Employee created...");

	}
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public LocalDate getJoiningdate() {
		return joiningdate;
	}
	public void setJoiningdate(LocalDate joiningdate) {
		this.joiningdate = joiningdate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
