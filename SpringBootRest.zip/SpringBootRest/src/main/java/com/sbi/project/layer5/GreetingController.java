package com.sbi.project.layer5;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/greetings")
public class GreetingController {
	@RequestMapping("/name")
	public String emp_name() {
		
		return "<h1>Welcome to the Spring Web Rest based application</h1>";
	}
	@RequestMapping("/welcome")
	public String welcomeMessage() {
		return "<h2>Welcome to the Spring Web based application</h2>";
	}
	@RequestMapping("/display")
	public String displayMessage() {
		Employee emp = new Employee();
		
		return "Employee Details :" +emp;
	}
	
}
