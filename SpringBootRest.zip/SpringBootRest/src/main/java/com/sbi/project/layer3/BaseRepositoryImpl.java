package com.sbi.project.layer3;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class BaseRepositoryImpl implements BaseRepository {
	@PersistenceContext

	// EntityManagerFactory entityManagerFactory;
	EntityManager entityManager;

	public BaseRepositoryImpl() {
		System.out.println("BaseDaoImpl()...");
	}

	public void persist(Object obj) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			entityManager.persist(obj);
		et.commit();
	}
	public void merge(Object obj) {
			entityManager.merge(obj);  }

	public void remove(Object obj) {
			entityManager.remove(obj); }
	
	public <E> E find(Class<E> className, Serializable primaryKey) {
			E e = entityManager.find(className, primaryKey);
			return e;	}
	
	public <E> List<E> findall(String entityName) {
			Query query = entityManager.createQuery("from " + entityName);
			return query.getResultList();
	}
}
