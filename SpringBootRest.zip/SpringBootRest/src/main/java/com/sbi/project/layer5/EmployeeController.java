package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emps")
public class EmployeeController {
	
	ArrayList<Employee> staff = new ArrayList<Employee>();
	
	public EmployeeController() {
		System.out.println("Employee Controller() constructor...");
		Employee employee1 = new Employee(26,"Veera","Doctor",LocalDate.of(2022, 4, 2),45000,"27");
		Employee employee2 = new Employee(27,"Jerry","Engineer",LocalDate.of(2022, 5, 21),35000,"35");
		Employee employee3 = new Employee(28,"Orlie","Banker",LocalDate.of(2021, 5, 18),45000,"25");
		Employee employee4 = new Employee(29,"Paul","IT Professional",LocalDate.of(2021, 5, 9),75000,"27");
		staff.add(employee1);
		staff.add(employee2);
		staff.add(employee3);
		staff.add(employee4);	
		}
	
	@RequestMapping("/getEmps")
	public List<Employee> getAllEmployees(){
		System.out.println("/getEmps");
		return staff;
	}
	
	@RequestMapping("/getEmp/{eno}")
	public Employee getEmployee(@PathVariable("eno") int employeeNumberToSearch) {
		System.out.println("/{eno}");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeNumberToSearch) {
				employeeFound=true;
				break;
			}
		}
		if(employeeFound==true)
		return employeeObject;
		else
			return null;
	}

	@RequestMapping("/deleteEmp/{eno}")
	public String deleteEmployee(@PathVariable("eno") int employeeNumberToDelete) {
		System.out.println("/{eno}");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeNumberToDelete) {
				employeeFound=true;
				staff.remove(i);
				break;
			}
		}
		if(employeeFound==true)
		return "Employee Object deleted" +employeeNumberToDelete;
		else
			return "Employee Object not Found :" +employeeNumberToDelete;
	}
	
	@RequestMapping("/updateEmp")
	public String updateEmployee(@RequestBody Employee employeeObjectToModify) {
		System.out.println("/updateEmp");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeObjectToModify.getEmployeeNumber()) {
				employeeFound=true;
				staff.remove(i);
				staff.add(employeeObjectToModify);
				break;
			}
		}
		if(employeeFound==true)
		return "Employee Object Successfully modified";
		else
			return "Employee Object not found: "+employeeObjectToModify.getEmployeeNumber();
	}
	@RequestMapping("/addEmp")
	public String addEmployee(@RequestBody Employee employeeObjectToAdd) {
		System.out.println("/addEmp");
		boolean employeeFound =false;
		Employee employeeObject = null;
		
		for(int i=0;i<staff.size();i++) {
			employeeObject = staff.get(i);
			if(employeeObject.getEmployeeNumber()== employeeObjectToAdd.getEmployeeNumber()) {
				employeeFound=true;
				break;
			}
		}
		if(employeeFound==true)
		return "Employee already exists :" +employeeObjectToAdd.getEmployeeNumber();
		else
			staff.add(employeeObjectToAdd);
			return "Employee Object added successfully";
	}
}
