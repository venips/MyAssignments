package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;

@Service
public interface ApplicantService {
	void createApplicationService (Applicant appl);
	List<Applicant> getAllApplicants();
	void modifyApplication(Applicant account);

	Applicant findApplication(int applicantId);
	void removeApplication(int applicantId);
}
