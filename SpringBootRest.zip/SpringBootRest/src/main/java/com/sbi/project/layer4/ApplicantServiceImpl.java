package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;

@Service
public class ApplicantServiceImpl implements ApplicantService {

	@Autowired
	ApplicantRepository applRepo;
	
	@Override
	public void createApplicationService(Applicant appl) {
	
		applRepo.createApplication(appl);
		System.out.println("ApplicantserviceImpl() :Created the applicants data..");
	}
	@Override
	public List<Applicant> getAllApplicants(){
	return applRepo.findallApplicants();
}
	
	public void modifyApplication(Applicant account) {
		// TODO Auto-generated method stub
		
		boolean applicantFound=false;
		Applicant appObject = null;
		
		List<Applicant> ls= applRepo.findallApplicants();
		for(int i=0;i<ls.size();i++) {
			appObject = ls.get(i);
			if(appObject.getApplicantId() == account.getApplicantId()) {
				applicantFound = true;
				
				break;
			}
		}
		if(applicantFound==true)
			{
			//appRepo.removeApplication(account.getApplicantId());
			applRepo.modifyApplication(account);
			}
		else	
			throw new RuntimeException("Applicant Not Found");
		
		
		
		
	}

	public void removeApplication(int applicantId) {
		// TODO Auto-generated method stub
		
		boolean applicantFound=false;
		Applicant appObject = null;
		
		List<Applicant> ls= applRepo.findallApplicants();
		for(int i=0;i<ls.size();i++) {
			appObject = ls.get(i);
			if(appObject.getApplicantId() == applicantId) {
				applicantFound = true;
				break;
			}
		}
		if(applicantFound==true)	applRepo.removeApplication(applicantId);	
		else	
			throw new RuntimeException("Applicant Not Found");
		
		
		
		
	}

	
	public Applicant findApplication(int applicantId) {
		// TODO Auto-generated method stub
		
		
		boolean applicantFound=false;
		Applicant appObject = null;
		
		List<Applicant> ls= applRepo.findallApplicants();
		for(int i=0;i<ls.size();i++) {
			appObject = ls.get(i);
			if(appObject.getApplicantId() == applicantId) {
				applicantFound = true;
				break;
			}
		}
		if(applicantFound==true)	return appObject;	
		else	
			throw new RuntimeException("Applicant Not Found");
		
	}
	
}
