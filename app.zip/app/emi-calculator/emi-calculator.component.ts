import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emi-calculator',
  templateUrl: './emi-calculator.component.html',
  styleUrls: ['./emi-calculator.component.css']
})
export class EmiCalculatorComponent implements OnInit {

  loanamount: number=300000;
  year: number=10;
  ior: number=10.5;
  emi:number=0;
  r=this.ior/12/100;
  constructor() { }

  ngOnInit(): void {
  }
  calculateEmi()
  {
    console.log("calculateEmi() is Invoked");
    console.log("value of r is "+this.r);
    //this.emi=this.loanamount*this.r*(((1+this.r)^this.year)/((1+this.r)^this.year-1));
    this.emi=this.loanamount*this.r*(1+this.r)^this.year/((1+this.r)^this.year-1);
  }

}
