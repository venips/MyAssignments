export class Applicant
{
    applicantId: number=0;
    applicantName: string="";
    applicantStatus: string="";
    accountappliedfor: string="" ;
}