import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {

  constructor() { }
  addTwoNumberService(x: number,y: number): number
  {
      console.log("CalculatorService addTwoNumberService()");
      return x+y;

  }
  substractTwoNumberService(x: number,y: number): number
  {
      console.log("CalculatorService substractTwoNumberService()");
      return x-y;

  }
  multiplyTwoNumberService(x: number,y: number): number
  {
      console.log("CalculatorService multiplyTwoNumberService()");
      return x*y;

  }
  divideTwoNumberService(x: number,y: number): number
  {
      console.log("CalculatorService divideTwoNumberService()");
      return x/y;

  }
}
