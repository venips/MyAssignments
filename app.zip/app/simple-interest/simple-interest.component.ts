import { Component, OnInit } from '@angular/core';
//import { ConsoleReporter } from 'jasmine';

@Component({
  selector: 'app-simple-interest',
  templateUrl: './simple-interest.component.html',
  styleUrls: ['./simple-interest.component.css']
})
export class SimpleInterestComponent implements OnInit {
  principal: number=5000 ;  //DATA MEMBERS
  numberOfYears: number=10;
  rate: number=4.5;
  si:number=0;

  constructor() { }

  ngOnInit(): void {
  }
  calculateSimpleInterest(){    //memberfunction
    console.log("calculateSimpleInterest() is invoked");
    this.si=(this.principal*this.numberOfYears*this.rate)/100;
    

  }

}
