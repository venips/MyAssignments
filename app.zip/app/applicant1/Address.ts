export class Address
{
     addresstype: string="";
     addressid: number=0;
	 street: string="";
	 area: string="";
	 city: string="";
	 state: string="";
	 country: string="";
	 pin:number=0;
}