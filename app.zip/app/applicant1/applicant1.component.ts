import { Component, OnInit } from '@angular/core';
import { Applicant } from '../applicant/Applicant';
import { Applicant1Service } from '../applicant1.service';
import { Applicant1 } from './Applicant1';

@Component({
  selector: 'app-applicant1',
  templateUrl: './applicant1.component.html',
  styleUrls: ['./applicant1.component.css']
})
export class Applicant1Component implements OnInit {

  applicant: Applicant1=new Applicant1();
  appid: number= this.applicant.applicantid;
  applicantArray: Applicant1[]=[];
  constructor(private appServ:Applicant1Service) { }

  ngOnInit(): void {
  }

  showAllUsers()  
  {
    this.appServ.loadAllApplicantsService().subscribe(
        (data:Applicant1[]) =>
        {
          console.log("in show all users");
          this.applicantArray=data;
        },
        (err) =>
        {
          console.log(err);
        }
        
    );

  }
  deleteApplicant(appid: number) 
  { 
    this.appServ.deleteApplicantService(appid).subscribe(
        (data:Applicant1) =>
        {
          console.log("in delete appplicant component");
          this.applicant=data;
        },
      (err) =>
      {
        console.log(err);
      }

    );

  }
}
