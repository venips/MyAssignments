import { Address } from './Address';

export class Applicant1
{
    applicantid: number=0;
	accountType: string="";
	applicantName: string="";
    applicantBirthDate: string="";
    applicantFatherName: string="";
    married: string="";
	applicantMobile: string="";
	occupation: string="";
    annualIncome: string="";
	addressList: Address[]=[];
	adhdaarNumber: string="";
	panCard: string="";
	photo: string="";
	applicationStatus: string="";


}