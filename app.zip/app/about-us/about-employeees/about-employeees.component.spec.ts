import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutEmployeeesComponent } from './about-employeees.component';

describe('AboutEmployeeesComponent', () => {
  let component: AboutEmployeeesComponent;
  let fixture: ComponentFixture<AboutEmployeeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AboutEmployeeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutEmployeeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
