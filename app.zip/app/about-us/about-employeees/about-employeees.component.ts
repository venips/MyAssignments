import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-employeees',
  templateUrl: './about-employeees.component.html',
  styleUrls: ['./about-employeees.component.css']
})
export class AboutEmployeeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
