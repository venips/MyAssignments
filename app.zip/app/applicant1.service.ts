import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { Applicant1 } from './applicant1/Applicant1';


@Injectable({
  providedIn: 'root'
})
export class Applicant1Service {

  baseURL:string='http://localhost:8080/applicant';

  constructor(private myHttp: HttpClient) { }

  loadAllApplicantsService(): Observable<Applicant1[]>
  {
      console.log(this.baseURL+"/getApplicants");    
      return this.myHttp.get<Applicant1[]>(this.baseURL+"/getApplicants");
      
  }
  deleteApplicantService(appid: number) : Observable<Applicant1>
  {
    console.log("in delete applicant service , appid ="+appid);
    console.log(this.baseURL+"/DeleteApp/"+appid);
    return this.myHttp.delete<Applicant1>(this.baseURL+"/DeleteApp/"+appid);
    
  }
  addApplicantService(newApplicant: Applicant1): Observable<any> 
  {
    console.log("invoking addApplicantService()");
    return this.myHttp.post<any>(this.baseURL+"/addApp",newApplicant,{responseType:'text' as 'json'});
    
  }


}
