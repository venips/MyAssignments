import { Component, OnInit } from '@angular/core';
import { UserDetailsService } from '../user-details.service';
import { UserDetails } from './UserDetails';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
 
  tempUserId: number=1;
  userDetails: UserDetails= new UserDetails();
  userDetailsArray: UserDetails[]=[];
  constructor(private uds:UserDetailsService) 
  {

  }

  ngOnInit(): void {
  }
  showUserDetails()
  {
    this.uds.fetchUserDetailsService(this.tempUserId).subscribe(
        (data: UserDetails) =>
        {
            this.userDetails=data;
            console.log(data);
        },
        (err)=>
        {
          console.log(err);
        }


    );
  }
  showAllUserDetails()
  {
      this.uds.fetchAllUserDetailsService().subscribe(
        (data:UserDetails[]) =>
        {
          this.userDetailsArray= data;
          console.log(data);
        },
        (err) =>
        {
          console.log(err);
        }
        
      );
  }

}
