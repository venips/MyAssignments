import { GeoLocation } from "./GeoLocation";

export class Address
{
    street: string="Kulas Light";
    suite: string="Apt. 556";
    city: string="Gwenborough";
    zipcode: string="92998-3874";
    geo: GeoLocation = new GeoLocation();
}