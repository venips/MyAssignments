

export class GeoLocation
{
    lat: string="-37.3159";
    lng: string="81.1496";
}