import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
//import { StatementComponent } from '../statement/statement.component';



@NgModule({

  providers: [DatePipe],
  declarations: [
    
    //StatementComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[]
})
export class StatementModule { }
