import { Component, OnInit } from '@angular/core';
import { StatementService } from '../statement.service';
import { Statement } from './Statement';
import { Account } from './Account';


@Component({
  selector: 'app-statement',
  templateUrl: './statement.component.html',
  styleUrls: ['./statement.component.css']
})
export class StatementComponent implements OnInit {


  statement:Statement = new Statement();


  accountnumber: Account=this.statement.debitAccountNumber;
  trdate: Date = new Date();
  trdate1: Date = new Date();

  statArray: Statement[]=[];
  
  
  constructor(private statementServ: StatementService) { }

  ngOnInit(): void {
  }
  getstatement(accountnumber:Account,fromDate:Date,toDate:Date)
  {
    if(accountnumber.accountNumber==0)
    {
        alert("please enter valid account number");
    }else{
    this.statementServ.getStatementServ(accountnumber,fromDate,toDate).subscribe(
        (data : Statement[]) =>
        {

          console.log("in getstatment in ts file ");
          this.statArray=data;
          console.log(data);
        },
        (err) =>
        {
          console.log(err);
        }

    );
      }
  }

}
