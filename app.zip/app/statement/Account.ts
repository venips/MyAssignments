export class Account{

    accountNumber: number=0;
    accountName: string ="";
    accountBalance: number=0;

}