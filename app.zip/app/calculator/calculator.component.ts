import { Component, OnInit } from '@angular/core';
import { CalculatorService } from '../calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {
  a: number=0;
  b: number=0;
  answer: number=0;

  constructor(private calServ: CalculatorService) {  }

  ngOnInit(): void {
  }

  

  addNumbers()
  {
    console.log("ADD");
    this.answer=this.calServ.addTwoNumberService(this.a,this.b);
    return this.answer;
  }
  substractNumbers()
  {
    console.log("SUBSTRACT");
    this.answer=this.calServ.substractTwoNumberService(this.a,this.b);
    return this.answer;
  }
  multiplyNumbers(){
    console.log("MULTIPLY");
    this.answer=this.calServ.multiplyTwoNumberService(this.a,this.b);
    return this.answer;
  }
  divideNumbers()
  {
    console.log("DIVIDE");
    this.answer=this.calServ.divideTwoNumberService(this.a,this.b);
    return this.answer;
  }

}
