import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RTGSTransferComponent } from './rtgstransfer/rtgstransfer.component';
import { NEFTTransferComponent } from './nefttransfer/nefttransfer.component';



@NgModule({
  declarations: [
    RTGSTransferComponent,
    NEFTTransferComponent
  ],
  imports: [
    CommonModule
  ],
  exports:
  [
    RTGSTransferComponent,
    NEFTTransferComponent
  ]
})
export class TransferModule { }
