import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rtgstransfer',
  templateUrl: './rtgstransfer.component.html',
  styleUrls: ['./rtgstransfer.component.css']
})
export class RTGSTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
