import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutCompanyComponent } from './about-us/about-company/about-company.component';
import { AboutEmployeeesComponent } from './about-us/about-employeees/about-employeees.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import { StatementComponent } from './statement/statement.component';
import { HomeComponent } from './home/home.component';
const routes: Routes = [
    {path:'',redirectTo:'home',pathMatch:'full'},
    {path: 'login',component:LoginComponent},
    {path: 'statement',component:StatementComponent},

    {path: 'about-us',
      children: [
          {path: '',component:AboutUsComponent},
          {path: 'about-emp',component:AboutEmployeeesComponent},
          {path: 'about-cmp',component:AboutCompanyComponent}
      ] 
    },

    {path: 'home',component:HomeComponent},
    {path: 'register',component:RegisterComponent},
    {path: 'contact-us',component:ContactUsComponent},
    {path:'**',component:PageNotFoundComponent},
    
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
