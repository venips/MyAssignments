import { Component, OnInit } from '@angular/core';
import { CurrencyConverterService } from '../currency-converter.service';

@Component({
  selector: 'app-currency-converter',
  templateUrl: './currency-converter.component.html',
  styleUrls: ['./currency-converter.component.css']
})
export class CurrencyConverterComponent implements OnInit {
  a: string="";
  b: string="";
  c: number=0;
  output: number=0;

  constructor(private curServ: CurrencyConverterService) { }

  ngOnInit(): void {
  }
  currencycon()
  {
      console.log("in currencycon()");
      this.output=this.curServ.convertCurrency(this.a,this.b,this.c);
      return this.output;
  }
}
