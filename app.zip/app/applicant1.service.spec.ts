import { TestBed } from '@angular/core/testing';

import { Applicant1Service } from './applicant1.service';

describe('Applicant1Service', () => {
  let service: Applicant1Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Applicant1Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
