import { Component, OnInit } from '@angular/core';

import { Applicant1Service } from '../applicant1.service';
import { Address } from '../applicant1/Address';
import { Applicant1 } from '../applicant1/Applicant1';


@Component({
  selector: 'app-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.css']
})
export class ApplyComponent implements OnInit {

  applicant: Applicant1 = new Applicant1();
  address1: Address = new Address();
  address2: Address = new Address();
  msg:any="";
  constructor(private applyServ: Applicant1Service) { }

  ngOnInit(): void {
  }
  applyForBankAccount()
  {
    this.address1.addresstype='Permanent';
    this.address2.addresstype='Correspondence';

    this.applicant.addressList.push(this.address1);
    this.applicant.addressList.push(this.address2);
    this.applyServ.addApplicantService(this.applicant).subscribe(
      (data:any) =>
      {
          console.log("in applyfor bank()");
          this.msg = data;
          console.log(data);
          console.log(this.msg);

      },
      
        (err) =>
        {
            console.log(err);

        }
      
    );
  }
}
