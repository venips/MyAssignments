import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewPayeeComponent } from './view-payee/view-payee.component';
import { ViewAllPayeeComponent } from './view-all-payee/view-all-payee.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { AddPayeeComponent } from './add-payee/add-payee.component';



@NgModule({
  declarations: [
    ViewPayeeComponent,
    ViewAllPayeeComponent,
    DeletePayeeComponent,
    AddPayeeComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[ViewPayeeComponent,
    ViewAllPayeeComponent,
    DeletePayeeComponent,
    AddPayeeComponent]
})
export class PayeeModule { }
