import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MainbodyComponent } from './mainbody/mainbody.component';
import { MenubarComponent } from './menubar/menubar.component';
import { SimpleInterestComponent } from './simple-interest/simple-interest.component';
import { FormsModule } from '@angular/forms';
import { EmiCalculatorComponent } from './emi-calculator/emi-calculator.component';

import { AddpayeeComponent } from './addpayee/addpayee.component';
import { ApplicantComponent } from './applicant/applicant.component';

import { StatementModule } from './statement/statement.module';
import { PayeeModule } from './payee/payee.module';
import { CalculatorComponent } from './calculator/calculator.component';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';
import { HttpClientModule } from '@angular/common/http';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { Applicant1Component } from './applicant1/applicant1.component';
import { ApplyComponent } from './apply/apply.component';
import { StatementComponent } from './statement/statement.component';
import { RegisterComponent } from './register/register.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { AboutEmployeeesComponent } from './about-us/about-employeees/about-employeees.component';
import { AboutCompanyComponent } from './about-us/about-company/about-company.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MainbodyComponent,
    MenubarComponent,
    SimpleInterestComponent,
    EmiCalculatorComponent,
    AddpayeeComponent,
    ApplicantComponent,
    CalculatorComponent,
    CurrencyConverterComponent,
    UserdetailsComponent,
    Applicant1Component,
    ApplyComponent,
    StatementComponent,
    RegisterComponent,
    ContactUsComponent,
    AboutUsComponent,
    AboutEmployeeesComponent,
    AboutCompanyComponent,
    LoginComponent,
    PageNotFoundComponent,
    HomeComponent,
    DashboardComponent,StatementComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(

      [
        {path:'statment',component:StatementComponent}
    ]
    ),
  
    FormsModule,
    PayeeModule,
    StatementModule,
    HttpClientModule
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
