import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { UserDetails } from './userdetails/UserDetails';


@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  constructor(private myHttp:HttpClient) { }

  fetchUserDetailsService(userid:number) : Observable<UserDetails>
  {
    return this.myHttp.get<UserDetails>("https://jsonplaceholder.typicode.com/users/"+userid);

  }

  fetchAllUserDetailsService() : Observable<UserDetails[]>
  {
    return this.myHttp.get<UserDetails[]>("https://jsonplaceholder.typicode.com/users/");

  }


}

