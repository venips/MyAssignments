import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {
  a1: number=0;
  constructor() { }
  convertCurrency(s: string,t:string,a: number)
  {
    
    console.log("In covnerCurrencyService()");
      if(s=="USA" && t=="INDIA")
      {
        console.log("in if ");
        this.a1=a*70;
        return this.a1;
      }
      else{
        console.log("in Else");
        return 0;
      }
  }


}
