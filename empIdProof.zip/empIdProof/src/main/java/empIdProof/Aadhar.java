package empIdProof;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Aadhar {
	@Id
	private int aadharNo;
	private String name;
	private String gender;
	private LocalDate dob;
	private String add;
	public int getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(int aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	@Override
	public String toString() {
		return "Aadhar [aadharNo=" + aadharNo + ", name=" + name + ", gender=" + gender + ", dob=" + dob + ", add="
				+ add + ", getAadharNo()=" + getAadharNo() + ", getName()=" + getName() + ", getGender()=" + getGender()
				+ ", getDob()=" + getDob() + ", getAdd()=" + getAdd() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
}
