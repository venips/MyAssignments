package empIdProof;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.Test;

import junit.framework.Assert;

public class TestingId {
	
	EntityManagerFactory emf;
	EntityManager em ;

	public TestingId() {
		System.out.println("CrudTesting()....");
		
				System.out.println("Trying to read persistence.xml file...");
				
				this.emf = Persistence.createEntityManagerFactory("MyJPA");
				System.out.println("EntityManagerFactory created....");
				
				this.em = emf.createEntityManager();
				System.out.println("EntityManager created....");
	}
	
	@Test
	public void createEmployeeTest() {
		EntityTransaction et = em.getTransaction();
		System.out.println("EntityTransaction created....");
		
		System.out.println("Trying to create record.....");
		
		Employee theEmp = new Employee();
		theEmp.setName("Julie");
		theEmp.setJob("Clerk");
		theEmp.setJoiningdate(LocalDate.of(2019, 6, 22));
		theEmp.setSalary(52000);
		theEmp.setAge(22);
		
//		Employee theEmp1 = new Employee();
//		theEmp1.setName("Ram");
//		theEmp1.setJob("Manager");
//		theEmp1.setJoiningdate(LocalDate.of(2010, 4, 20));
//		theEmp1.setSalary(70000);
//		theEmp1.setAge(35);
		
		Aadhar aadhar = new Aadhar();
		aadhar.setAadharNo(456123567);
		aadhar.setName("Karthik");
		aadhar.setGender("Male");
		aadhar.setAdd("Bangalore");
		aadhar.setDob(LocalDate.of(2010, 12, 8));
		
		VoterId voterid = new VoterId();
		voterid.setAdd("XED4568");
		voterid.setName("Moorthy");
		voterid.setFatherName("Sankar");
		voterid.setGender("Male");
		voterid.setDob(LocalDate.of(1963, 5, 17));
		
		PanCard pancard = new PanCard();
		pancard.setPanno("AOGPV7275N");
		pancard.setName("Sreejan");
		pancard.setFatherName("Amit");
		pancard.setDob(LocalDate.of(2011, 3, 21));
		
		theEmp.setAadhar(aadhar);
		theEmp.setVoterid(voterid);
		theEmp.setPancard(pancard);
		
		EntityTransaction tx = em.getTransaction();
		et.begin();
		em.persist(theEmp);
		//em.persist(theEmp1);
		et.commit();
	}
	
	@Test
	public void findAllEmp() {
		
	
		EntityTransaction et = em.getTransaction();
	Assert.assertTrue(em!=null);
		System.out.println("EntityTransaction created....");
		
		System.out.println("Trying to read record.....");
		
		Query query = em.createQuery("from Employee"); 
		List<Employee> staff = query.getResultList();
		
		
	Assert.assertTrue(staff.size() > 0);
		for (Employee theEmp : staff) {
				System.out.println("Emp number : "+theEmp.getEmployeeNumber());
				System.out.println("Emp name   : "+theEmp.getName());
				System.out.println("Emp doj    : "+theEmp.getJob());
				System.out.println("Emp salary : "+theEmp.getSalary());
				System.out.println("Emp age    : "+theEmp.getAge());
				System.out.println("------------------------------");
		}
		
	}
	}
 

